
import { GoogleGenAI, Type } from "@google/genai";
import { ToneStyle, AppMode, ScriptLength, ScriptSection, TitleAnalysis } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const rateTitle = async (
  title: string,
  niche: string,
  audience: string
): Promise<TitleAnalysis> => {
  const model = "gemini-3-pro-preview";
  
  const systemInstruction = `
    You are a YouTube Title Expert & Algorithm Strategist.
    Analyze the provided title based on CTR (Click-Through Rate) potential, curiosity gap, and search intent/keyword relevance for the niche: "${niche}" and audience: "${audience}".

    CRITERIA:
    1. Curiosity Gap: Does it make the user ask a question?
    2. Clarity/Keywords: Is it clear what the video is about (for Search)?
    3. Urgency/Emotion: Does it trigger a psychological response?

    OUTPUT RULES:
    - If the score is >= 85, verdict MUST be "Good to go!".
    - If the score is < 85, verdict MUST be "Needs Improvement".
    - If "Needs Improvement", provide at least 3 stronger alternatives.
    - If "Good to go!", you may still provide 1-2 superior variations if possible, otherwise leave alternatives empty.

    OUTPUT STRUCTURE (JSON):
    {
      "score": number (0-100),
      "verdict": "Good to go!" | "Needs Improvement",
      "feedback": "Brief, punchy explanation of the rating.",
      "alternatives": ["Alternative Title 1", "Alternative Title 2", "Alternative Title 3"]
    }
  `;

  const response = await ai.models.generateContent({
    model: model,
    contents: `Analyze this YouTube title: "${title}"`,
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          score: { type: Type.NUMBER },
          verdict: { type: Type.STRING, enum: ["Good to go!", "Needs Improvement"] },
          feedback: { type: Type.STRING },
          alternatives: { 
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        },
        required: ["score", "verdict", "feedback", "alternatives"]
      }
    },
  });

  return JSON.parse(response.text || "{}");
};

export const processScript = async (
  input: string,
  mode: AppMode,
  tone: ToneStyle,
  audience: string,
  niche: string,
  length: ScriptLength,
  section: ScriptSection,
  wordCount?: number
) => {
  const model = "gemini-3-pro-preview";

  const lengthInstruction = {
    shorten: "Aggressively condense the content. Remove fluff and get straight to the high-impact points while maintaining the human soul.",
    same: "Maintain a similar word count and structure to the original input. Do not lose key details, just humanize the delivery.",
    extend: "Expand on the ideas provided. Add relevant anecdotes, deeper explanations, or additional value to make the script significantly more detailed."
  }[length];

  const sectionInstruction = {
    full: "Write a complete, end-to-end YouTube script.",
    intro: "Focus purely on a high-retention HOOK and INTRO. It must grab the viewer within 3 seconds and explain the 'value-prop' of the video immediately.",
    middle: "Focus on a CORE SECTION of the script. Provide high-value, deep-niche technical details or storytelling that maintains engagement mid-video.",
    outro: "Focus on the CONCLUSION and CALL-TO-ACTION. It must feel natural, summarize the value, and transition into a high-CTR 'next video' prompt without sounding salesy.",
    description: "Write a high-converting, SEO-optimized YouTube Video Description. Include a strong hook in the first 2 lines (for the 'Show More' preview), natural keyword integration, timestamp placeholders if applicable, and relevant links/CTAs. Write in first-person."
  }[section];

  const wordCountMsg = wordCount ? `Aim for approximately ${wordCount} words.` : "";

  const systemInstruction = `
    You are the "2026 YouTube Authenticity & Growth Architect."
    Your mission: Rewrite or generate scripts that pass modern AI-Inauthentic content detection by utilizing "High-Entropy Spoken Patterns" and high-retention pacing.

    STRICT RULES:
    1. NO VISUAL CUES: Do not include stage directions, [Visuals], [B-Roll], [Camera Cuts], or audio instructions. The output must be PURE SPOKEN DIALOGUE (or text for descriptions).
    2. PLAIN TEXT FORMATTING: Output the script in plain text. Use double newlines (two enter presses) between paragraphs to ensure clear separation when copied to other editors.
    3. LENGTH & SCOPE: ${lengthInstruction} ${sectionInstruction} ${wordCountMsg}
    4. HUMAN IMPERFECTION: 
       - Inject "thinking beats" (e.g., "Actually, let me put it this way...", "I was thinking about this earlier and...").
       - Use non-standard sentence starts: "Because here's the thing...", "Which is why...", "And honestly?".
       - Vary sentence length aggressively. 1-word sentences followed by long, winding 30-word personal explanations.
    5. FORBIDDEN AI SIGNATURES: 
       - NEVER use: Delve, Tapestry, Comprehensive, Unleash, Landscape, Notably, Embark, In Conclusion, Let's Explore, In the ever-evolving world, Firstly/Secondly.
       - Avoid balanced lists (3 items of equal length). Humans are messy; use 2 items or 4 items with varying detail.
    6. NICHE SPECIFICITY (${niche}):
       - Use the jargon a practitioner uses, not a dictionary definition. 
    7. AUDIENCE CONNECTION (${audience}):
       - Use "Mirroring": Describe a specific feeling the audience has.
       - Break the fourth wall: "I know some of you are going to disagree in the comments, but hear me out."

    ${mode === 'generator' ? 
      "GENERATOR MODE: Create a viral script from the following prompt/topic." : 
      "HUMANIZER MODE: Rewrite the provided AI-sounding script to be indistinguishable from a top-tier human creator."
    }

    CONTEXT:
    - NICHE: ${niche}
    - TONE: ${tone}
    - AUDIENCE: ${audience}

    OUTPUT STRUCTURE (JSON):
    {
      "humanizedScript": "The full spoken-only script (or description text if 'description' selected). Plain text only. Use double newlines between paragraphs. No brackets. No visual cues.",
      "sheAnalysis": {
        "specificScore": 0-100,
        "humanScore": 0-100,
        "emotionalScore": 0-100,
        "explanation": "Briefly explain the specific 'entropy markers' injected."
      },
      "suggestedTitles": ["3 Viral, Curiosity-Gap Titles"],
      "description": "Short summary of the content generated.",
      "tags": ["Niche-specific tags"],
      "algorithmStrategy": "How this specific draft bypasses the 2026 Inauthentic Content flag."
    }
  `;

  // Note: title-rater mode is handled by rateTitle function, so we don't need logic for it here.
  const prompt = mode === 'generator' 
    ? `Generate a human-authentic YouTube content (${section}) for ${niche} about: ${input}`
    : `Strip all AI-isms and humanize this content (${section}) for ${niche}: ${input}`;

  const response = await ai.models.generateContent({
    model: model,
    contents: prompt,
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          humanizedScript: { type: Type.STRING },
          sheAnalysis: {
            type: Type.OBJECT,
            properties: {
              specificScore: { type: Type.NUMBER },
              humanScore: { type: Type.NUMBER },
              emotionalScore: { type: Type.NUMBER },
              explanation: { type: Type.STRING }
            },
            required: ["specificScore", "humanScore", "emotionalScore", "explanation"]
          },
          suggestedTitles: { 
            type: Type.ARRAY,
            items: { type: Type.STRING }
          },
          description: { type: Type.STRING },
          tags: { 
            type: Type.ARRAY,
            items: { type: Type.STRING }
          },
          algorithmStrategy: { type: Type.STRING }
        },
        required: ["humanizedScript", "sheAnalysis", "suggestedTitles", "description", "tags", "algorithmStrategy"]
      }
    },
  });

  return JSON.parse(response.text || "{}");
};
