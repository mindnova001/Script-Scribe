
export type ToneStyle = 
  | 'casual' 
  | 'storyteller' 
  | 'energetic' 
  | 'educational' 
  | 'controversial' 
  | 'documentary' 
  | 'rant' 
  | 'satirical' 
  | 'minimalist' 
  | 'urgent';

export type AppMode = 'humanizer' | 'generator' | 'title-rater';
export type ScriptLength = 'shorten' | 'same' | 'extend';
export type ScriptSection = 'full' | 'intro' | 'middle' | 'outro' | 'description';

export interface TitleAnalysis {
  score: number;
  verdict: 'Good to go!' | 'Needs Improvement';
  feedback: string;
  alternatives: string[];
}

export interface ScriptVersion {
  id: string;
  original: string;
  humanized: string;
  tone: ToneStyle;
  timestamp: number;
  niche?: string;
  metadata: {
    suggestedTitles: string[];
    description: string;
    tags: string[];
  };
}

export interface RewritingConfig {
  tone: ToneStyle;
  targetAudience: string;
  niche: string;
  includeHook: boolean;
  includeOutro: boolean;
}
