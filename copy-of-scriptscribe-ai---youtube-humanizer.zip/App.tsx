
import React, { useState, useRef } from 'react';
import { 
  Youtube, 
  Sparkles, 
  Settings2, 
  Copy, 
  Check, 
  AlertCircle,
  PlayCircle,
  MessageSquare,
  Zap,
  TrendingUp,
  BrainCircuit,
  ShieldCheck,
  ChevronRight,
  Eye,
  BarChart3,
  History,
  Mic2,
  Flame,
  Laugh,
  Leaf,
  Timer,
  Hash,
  PenTool,
  Filter,
  ChevronDown,
  ChevronUp,
  Scissors,
  StretchHorizontal,
  AlignLeft,
  Type as TypeIcon,
  Layout,
  Clock,
  Search,
  ThumbsUp,
  AlertTriangle,
  Square
} from 'lucide-react';
import { ToneStyle, ScriptVersion, AppMode, ScriptLength, ScriptSection, TitleAnalysis } from './types';
import { processScript, rateTitle } from './services/geminiService';

interface ExtendedScriptVersion extends ScriptVersion {
  sheAnalysis: {
    specificScore: number;
    humanScore: number;
    emotionalScore: number;
    explanation: string;
  };
  algorithmStrategy: string;
}

export default function App() {
  const [input, setInput] = useState('');
  const [mode, setMode] = useState<AppMode>('humanizer');
  const [tone, setTone] = useState<ToneStyle>('casual');
  const [length, setLength] = useState<ScriptLength>('same');
  const [section, setSection] = useState<ScriptSection>('full');
  const [wordCount, setWordCount] = useState<string>('');
  const [audience, setAudience] = useState('New Creators');
  const [niche, setNiche] = useState('Tech & Lifestyle');
  const [isLoading, setIsLoading] = useState(false);
  const [output, setOutput] = useState<ExtendedScriptVersion | null>(null);
  const [titleOutput, setTitleOutput] = useState<TitleAnalysis | null>(null);
  const [copied, setCopied] = useState(false);
  const [viewMode, setViewMode] = useState<'script' | 'strategy'>('script');
  const [isConfigExpanded, setIsConfigExpanded] = useState(true);

  const abortControllerRef = useRef<AbortController | null>(null);

  const handleStop = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsLoading(false);
  };

  const handleExecute = async () => {
    if (isLoading) {
      handleStop();
      return;
    }

    if (!input.trim()) return;
    
    // Setup abort controller
    const controller = new AbortController();
    abortControllerRef.current = controller;

    setIsLoading(true);
    
    // Clear previous outputs
    setOutput(null);
    setTitleOutput(null);

    try {
      if (mode === 'title-rater') {
        const result = await rateTitle(input, niche, audience);
        if (controller.signal.aborted) return;
        setTitleOutput(result);
      } else {
        const targetWords = wordCount ? parseInt(wordCount) : undefined;
        const result = await processScript(input, mode, tone, audience, niche, length, section, targetWords);
        if (controller.signal.aborted) return;

        const newVersion: ExtendedScriptVersion = {
          id: Math.random().toString(36).substr(2, 9),
          original: input,
          humanized: result.humanizedScript,
          tone: tone,
          timestamp: Date.now(),
          niche: niche,
          sheAnalysis: result.sheAnalysis,
          algorithmStrategy: result.algorithmStrategy,
          metadata: {
            suggestedTitles: result.suggestedTitles,
            description: result.description,
            tags: result.tags
          }
        };
        setOutput(newVersion);
      }
      
      if (window.innerWidth < 1024) setIsConfigExpanded(false);
    } catch (error) {
      if (controller.signal.aborted) return;
      console.error("Execution failed:", error);
      alert("System overload. Please refine your input and retry.");
    } finally {
      if (!controller.signal.aborted) {
        setIsLoading(false);
        abortControllerRef.current = null;
      }
    }
  };

  const copyToClipboard = (text: string) => {
    if (!text) return;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const ScoreBar = ({ label, score, color }: { label: string, score: number, color: string }) => (
    <div className="space-y-1">
      <div className="flex justify-between text-[10px] uppercase tracking-wider font-black text-gray-500">
        <span>{label}</span>
        <span>{score}%</span>
      </div>
      <div className="h-1 bg-white/5 rounded-full overflow-hidden">
        <div 
          className={`h-full ${color} transition-all duration-1000 ease-out`}
          style={{ width: `${score}%` }}
        />
      </div>
    </div>
  );

  const toneOptions: { id: ToneStyle; label: string; icon: React.ReactNode }[] = [
    { id: 'casual', label: 'Casual', icon: <Zap className="w-3.5 h-3.5" /> },
    { id: 'storyteller', label: 'Story', icon: <History className="w-3.5 h-3.5" /> },
    { id: 'energetic', label: 'Hype', icon: <PlayCircle className="w-3.5 h-3.5" /> },
    { id: 'educational', label: 'Guru', icon: <Sparkles className="w-3.5 h-3.5" /> },
    { id: 'documentary', label: 'Cinema', icon: <Mic2 className="w-3.5 h-3.5" /> },
    { id: 'rant', label: 'Rant', icon: <Flame className="w-3.5 h-3.5" /> },
    { id: 'satirical', label: 'Snarky', icon: <Laugh className="w-3.5 h-3.5" /> },
    { id: 'minimalist', label: 'Zen', icon: <Leaf className="w-3.5 h-3.5" /> },
    { id: 'urgent', label: 'Urgent', icon: <Timer className="w-3.5 h-3.5" /> },
    { id: 'controversial', label: 'Edge', icon: <AlertCircle className="w-3.5 h-3.5" /> },
  ];

  const sectionOptions: { id: ScriptSection; label: string }[] = [
    { id: 'full', label: 'Full Script' },
    { id: 'intro', label: 'Intro / Hook' },
    { id: 'middle', label: 'Section' },
    { id: 'outro', label: 'Conclusion' },
    { id: 'description', label: 'Description' },
  ];

  const getButtonText = () => {
    if (isLoading) return "STOP PROCESSING";
    if (mode === 'humanizer') return "FIX ROBOTIC SCRIPT";
    if (mode === 'generator') return "GENERATE VIRAL SCRIPT";
    if (mode === 'title-rater') return "ANALYZE TITLE";
    return "EXECUTE";
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#050505] selection:bg-red-500/30 text-gray-200">
      {/* Navigation */}
      <nav className="border-b border-white/5 bg-black/80 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-[1600px] mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-red-600 to-red-800 rounded-xl flex items-center justify-center shadow-lg shadow-red-500/20">
              <Youtube className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="font-black text-xl tracking-tighter text-white">SCRIPTSCRIBE <span className="text-red-500">PRO</span></h1>
              <p className="text-[10px] text-gray-500 uppercase font-bold tracking-[0.2em]">Authenticity Bypass Engine v4.0</p>
            </div>
          </div>
          
          <div className="hidden lg:flex items-center gap-8">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-white/5 rounded-full border border-white/10">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse shadow-[0_0_8px_rgba(34,197,94,0.6)]" />
              <span className="text-[11px] font-bold text-gray-300">S.H.E. PROTOCOL: ACTIVE</span>
            </div>
            <button className="px-5 py-2.5 bg-red-600 text-white rounded-xl text-xs font-black hover:bg-red-500 transition-all shadow-xl shadow-red-600/10 hover:shadow-red-600/20">
              GO UNLIMITED
            </button>
          </div>
        </div>
      </nav>

      <main className="flex-1 max-w-[1600px] mx-auto w-full p-4 lg:p-10 grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-10">
        {/* Input & Config Column */}
        <div className={`lg:col-span-4 flex flex-col gap-6 transition-all duration-300 ${!isConfigExpanded ? 'opacity-90' : ''}`}>
          <section className="bg-zinc-900/40 border border-white/5 rounded-3xl p-6 lg:p-8 backdrop-blur-sm relative overflow-hidden flex flex-col gap-6">
            
            <div className="flex items-center justify-between">
              <h2 className="text-[10px] font-black text-gray-500 uppercase tracking-widest flex items-center gap-2">
                <div className="w-1 h-3 bg-red-600 rounded-full" />
                Input Engine
              </h2>
              <button 
                onClick={() => setIsConfigExpanded(!isConfigExpanded)}
                className="lg:hidden p-2 bg-white/5 rounded-lg text-gray-400"
              >
                {isConfigExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
            </div>

            <div className="flex bg-black/40 p-1 rounded-2xl border border-white/5">
              <button 
                onClick={() => setMode('humanizer')}
                className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-[10px] font-black uppercase transition-all ${mode === 'humanizer' ? 'bg-zinc-800 text-white shadow-lg' : 'text-zinc-500 hover:text-zinc-300'}`}
              >
                <Filter className="w-3 h-3" /> Humanizer
              </button>
              <button 
                onClick={() => setMode('generator')}
                className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-[10px] font-black uppercase transition-all ${mode === 'generator' ? 'bg-zinc-800 text-white shadow-lg' : 'text-zinc-500 hover:text-zinc-300'}`}
              >
                <PenTool className="w-3 h-3" /> Generator
              </button>
              <button 
                onClick={() => setMode('title-rater')}
                className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-[10px] font-black uppercase transition-all ${mode === 'title-rater' ? 'bg-zinc-800 text-white shadow-lg' : 'text-zinc-500 hover:text-zinc-300'}`}
              >
                <Search className="w-3 h-3" /> Title Rater
              </button>
            </div>

            <textarea
              className="w-full h-[180px] bg-black/40 border border-white/10 rounded-2xl p-6 text-sm leading-relaxed focus:ring-1 focus:ring-red-500/50 outline-none resize-none placeholder:text-zinc-700 transition-all font-medium text-gray-300 shadow-inner"
              placeholder={
                mode === 'humanizer' ? "Paste your AI-generated script here..." : 
                mode === 'title-rater' ? "Enter your potential YouTube video title..." :
                "Describe the topic or provide key points..."
              }
              value={input}
              onChange={(e) => setInput(e.target.value)}
            />

            <div className={`space-y-5 transition-all duration-500 overflow-hidden ${isConfigExpanded ? 'max-h-[1200px] opacity-100' : 'max-h-0 opacity-0 pointer-events-none'}`}>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest flex items-center gap-1.5">
                    <Hash className="w-3 h-3" /> Niche
                  </label>
                  <input
                    type="text"
                    className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-[11px] font-bold focus:ring-1 focus:ring-red-500/50 outline-none text-white"
                    placeholder="e.g. Gaming"
                    value={niche}
                    onChange={(e) => setNiche(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest flex items-center gap-1.5">
                    <Eye className="w-3 h-3" /> Audience
                  </label>
                  <input
                    type="text"
                    className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-[11px] font-bold focus:ring-1 focus:ring-red-500/50 outline-none text-white"
                    placeholder="e.g. Students"
                    value={audience}
                    onChange={(e) => setAudience(e.target.value)}
                  />
                </div>
              </div>

              {/* Advanced controls only for script modes */}
              {mode !== 'title-rater' && (
                <>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest flex items-center gap-1.5">
                      <Layout className="w-3 h-3" /> Target Segment
                    </label>
                    <div className="grid grid-cols-5 gap-1 bg-black/40 p-1 rounded-xl border border-white/5">
                      {sectionOptions.map((opt) => (
                        <button 
                          key={opt.id}
                          onClick={() => setSection(opt.id)}
                          className={`py-2 rounded-lg text-[9px] font-black uppercase transition-all whitespace-nowrap overflow-hidden text-ellipsis px-1 ${section === opt.id ? 'bg-zinc-800 text-white shadow-md' : 'text-zinc-600 hover:text-zinc-400'}`}
                          title={opt.label}
                        >
                          {opt.label.split(' ')[0]}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-3">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest flex items-center gap-1.5">
                       <Clock className="w-3 h-3" /> Duration Control
                    </label>
                    <div className="flex bg-black/40 p-1 rounded-xl border border-white/5">
                      <button 
                        onClick={() => setLength('shorten')}
                        className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-[10px] font-bold uppercase transition-all ${length === 'shorten' ? 'bg-zinc-800 text-white shadow-md' : 'text-zinc-500 hover:text-zinc-300'}`}
                      >
                        <Scissors className="w-3 h-3" /> Shorten
                      </button>
                      <button 
                        onClick={() => setLength('same')}
                        className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-[10px] font-bold uppercase transition-all ${length === 'same' ? 'bg-zinc-800 text-white shadow-md' : 'text-zinc-500 hover:text-zinc-300'}`}
                      >
                        <AlignLeft className="w-3 h-3" /> Same
                      </button>
                      <button 
                        onClick={() => setLength('extend')}
                        className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-[10px] font-bold uppercase transition-all ${length === 'extend' ? 'bg-zinc-800 text-white shadow-md' : 'text-zinc-500 hover:text-zinc-300'}`}
                      >
                        <StretchHorizontal className="w-3 h-3" /> Extend
                      </button>
                    </div>
                    
                    <div className="relative group">
                      <div className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-600 group-focus-within:text-red-500 transition-colors">
                        <TypeIcon className="w-3 h-3" />
                      </div>
                      <input
                        type="number"
                        className="w-full bg-black/40 border border-white/10 rounded-xl p-3 pl-9 text-[11px] font-bold focus:ring-1 focus:ring-red-500/50 outline-none text-white placeholder:text-zinc-800"
                        placeholder="Optional Target Word Count (e.g. 500)"
                        value={wordCount}
                        onChange={(e) => setWordCount(e.target.value)}
                      />
                    </div>
                  </div>

                  {/* Tone is only relevant for script modes */}
                  <div className="space-y-3">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Human Voice Profile</label>
                    <div className="grid grid-cols-2 gap-2 max-h-[140px] overflow-y-auto pr-2 custom-scrollbar">
                      {toneOptions.map((style) => (
                        <button
                          key={style.id}
                          onClick={() => setTone(style.id)}
                          className={`flex items-center gap-2 p-3 rounded-xl border transition-all text-[11px] font-bold ${
                            tone === style.id 
                              ? 'border-red-500 bg-red-500/10 text-white shadow-[0_0_10px_rgba(239,68,68,0.1)]' 
                              : 'border-white/5 bg-white/5 text-gray-500 hover:bg-white/10'
                          }`}
                        >
                          {style.icon}
                          {style.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>

            <button
              onClick={isLoading ? handleStop : handleExecute}
              disabled={!isLoading && !input.trim()}
              className={`w-full py-5 rounded-2xl font-black text-sm flex items-center justify-center gap-3 transition-all relative overflow-hidden ${
                !isLoading && !input.trim()
                  ? 'bg-zinc-800 text-zinc-600 cursor-not-allowed opacity-50'
                  : isLoading 
                    ? 'bg-zinc-800 text-white hover:bg-zinc-700'
                    : 'bg-red-600 hover:bg-red-500 text-white shadow-2xl shadow-red-600/20 active:scale-95'
              }`}
            >
              {isLoading ? (
                <>
                  <Square className="w-5 h-5 fill-current animate-pulse" />
                  STOP PROCESSING
                </>
              ) : (
                <>
                  <BrainCircuit className="w-5 h-5" />
                  {getButtonText()}
                </>
              )}
            </button>
          </section>
        </div>

        {/* Output Column */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          {!output && !titleOutput ? (
            <div className="flex-1 bg-zinc-900/10 border border-dashed border-white/5 rounded-[40px] flex flex-col items-center justify-center p-12 text-center group">
              <div className="w-20 h-20 bg-white/5 rounded-3xl flex items-center justify-center mb-8 border border-white/5 group-hover:scale-105 transition-transform duration-500">
                <Sparkles className="w-8 h-8 text-zinc-800 group-hover:text-red-500/50" />
              </div>
              <h3 className="text-xl font-black text-zinc-500 mb-2 uppercase tracking-tighter">Bypass Protocol Standby</h3>
              <p className="text-zinc-600 max-w-sm font-medium leading-relaxed text-sm">
                Enter your topic or script to begin. Our engine will strip all AI markers and inject human-perfect imperfections for the <span className="text-red-500/80 uppercase font-black">{niche}</span> niche.
              </p>
            </div>
          ) : titleOutput ? (
            /* Title Rater Output */
            <div className="animate-in fade-in slide-in-from-right-10 duration-500 flex flex-col gap-6">
               <div className="bg-zinc-900/40 border border-white/5 rounded-[32px] overflow-hidden shadow-2xl p-8 lg:p-12 relative">
                  <div className="flex flex-col lg:flex-row gap-10 items-center">
                    {/* Score Circle */}
                    <div className="relative w-40 h-40 flex items-center justify-center shrink-0">
                      <div className="absolute inset-0 rounded-full border-[6px] border-white/5"></div>
                      <div className={`absolute inset-0 rounded-full border-[6px] ${titleOutput.score >= 85 ? 'border-green-500' : 'border-red-500'} border-r-transparent rotate-45`}></div>
                      <div className="text-center">
                        <span className="text-4xl font-black text-white">{titleOutput.score}</span>
                        <div className="text-[10px] text-gray-500 font-bold uppercase tracking-widest mt-1">Score</div>
                      </div>
                    </div>

                    <div className="flex-1 space-y-4 text-center lg:text-left">
                       <h3 className={`text-3xl font-black uppercase italic ${titleOutput.score >= 85 ? 'text-green-500' : 'text-red-500'}`}>
                         {titleOutput.verdict === 'Good to go!' ? (
                            <span className="flex items-center gap-3 justify-center lg:justify-start">
                              <ThumbsUp className="w-8 h-8" /> GOOD TO GO!
                            </span>
                         ) : (
                            <span className="flex items-center gap-3 justify-center lg:justify-start">
                               <AlertTriangle className="w-8 h-8" /> NEEDS IMPROVEMENT
                            </span>
                         )}
                       </h3>
                       <p className="text-gray-300 text-lg font-medium leading-relaxed">
                         {titleOutput.feedback}
                       </p>
                    </div>
                  </div>

                  {/* Alternatives */}
                  {titleOutput.alternatives && titleOutput.alternatives.length > 0 && (
                     <div className="mt-12 space-y-4">
                        <h4 className="text-[11px] font-black text-gray-500 uppercase tracking-[0.2em] mb-6 flex items-center gap-2">
                           <Sparkles className="w-4 h-4 text-blue-500" /> 
                           {titleOutput.verdict === 'Good to go!' ? 'Viral Variations (Optional)' : 'Recommended Alternatives'}
                        </h4>
                        <div className="grid gap-3">
                           {titleOutput.alternatives.map((alt, i) => (
                             <div key={i} className="group p-5 bg-white/5 rounded-2xl border border-white/5 hover:border-blue-500/50 hover:bg-white/10 transition-all flex items-center justify-between cursor-pointer" onClick={() => copyToClipboard(alt)}>
                                <span className="font-bold text-lg text-white group-hover:text-blue-200">{alt}</span>
                                <Copy className="w-4 h-4 text-gray-500 group-hover:text-white" />
                             </div>
                           ))}
                        </div>
                     </div>
                  )}
               </div>
            </div>
          ) : (
            /* Script Output */
            <div className="animate-in fade-in slide-in-from-right-10 duration-500 flex flex-col gap-6">
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="md:col-span-3 bg-zinc-900/40 border border-white/5 rounded-3xl p-6 backdrop-blur-sm flex items-center justify-between">
                  <div className="flex items-center gap-6">
                    <div className="w-12 h-12 bg-green-500/10 rounded-2xl flex items-center justify-center border border-green-500/20">
                      <TrendingUp className="w-6 h-6 text-green-500" />
                    </div>
                    <div>
                      <h4 className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Spoken Authenticity Score</h4>
                      <p className="text-2xl font-black text-white">99.8% <span className="text-[10px] text-green-500 align-top tracking-widest font-black ml-2 uppercase">Verified</span></p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button 
                      onClick={() => setViewMode('script')}
                      className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase transition-all flex items-center gap-2 ${viewMode === 'script' ? 'bg-white text-black' : 'bg-white/5 text-gray-400 hover:text-white'}`}
                    >
                      <MessageSquare className="w-3 h-3" /> Script
                    </button>
                    <button 
                      onClick={() => setViewMode('strategy')}
                      className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase transition-all flex items-center gap-2 ${viewMode === 'strategy' ? 'bg-white text-black' : 'bg-white/5 text-gray-400 hover:text-white'}`}
                    >
                      <ShieldCheck className="w-3 h-3" /> Report
                    </button>
                  </div>
                </div>
                
                <div className="bg-zinc-900/40 border border-white/5 rounded-3xl p-6 backdrop-blur-sm space-y-3">
                   {output && (
                     <>
                        <ScoreBar label="Specifics" score={output.sheAnalysis.specificScore} color="bg-blue-500" />
                        <ScoreBar label="Nuance" score={output.sheAnalysis.humanScore} color="bg-red-500" />
                        <ScoreBar label="Retention" score={output.sheAnalysis.emotionalScore} color="bg-orange-500" />
                     </>
                   )}
                </div>
              </div>

              {/* Main Content Area */}
              <div className="bg-zinc-900/40 border border-white/5 rounded-[32px] overflow-hidden flex flex-col min-h-[500px] shadow-2xl relative">
                <div className="bg-white/5 p-4 px-6 flex items-center justify-between border-b border-white/5 backdrop-blur-md">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-red-600 animate-pulse shadow-[0_0_8px_rgba(220,38,38,0.5)]" />
                    <span className="font-black text-[10px] uppercase tracking-[0.2em] text-gray-400">
                      Production: {output?.niche?.toUpperCase()} // {output?.tone?.toUpperCase()} PROFILE
                    </span>
                  </div>
                  {output && (
                    <button
                      onClick={() => copyToClipboard(viewMode === 'script' ? output.humanized : output.algorithmStrategy)}
                      className="flex items-center gap-2 px-3 py-1.5 bg-white/5 hover:bg-white/10 rounded-xl text-[10px] font-black uppercase border border-white/5 transition-colors"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
                      Copy Content
                    </button>
                  )}
                </div>
                
                <div className="p-8 lg:p-12 flex-1 whitespace-pre-wrap text-gray-300 leading-[1.8] text-lg font-medium">
                  {output && viewMode === 'script' ? (
                    <div className="animate-in fade-in duration-300 max-w-3xl mx-auto">
                      {output.humanized.split(/\n\n+/).map((para, i) => (
                        <p key={i} className="mb-6 text-gray-200">
                          {para}
                        </p>
                      ))}
                    </div>
                  ) : output && (
                    <div className="animate-in slide-in-from-bottom-4 duration-300 space-y-8 max-w-3xl mx-auto">
                      <div className="p-6 bg-red-500/5 rounded-3xl border border-red-500/10">
                        <h5 className="text-red-500 font-black text-xs uppercase mb-3 flex items-center gap-2">
                          <Zap className="w-3 h-3" /> Anti-Detection Rationale
                        </h5>
                        <p className="text-sm text-gray-400 leading-relaxed font-semibold">{output.algorithmStrategy}</p>
                      </div>
                      <div className="p-6 bg-blue-500/5 rounded-3xl border border-blue-500/10">
                        <h5 className="text-blue-500 font-black text-xs uppercase mb-3 flex items-center gap-2">
                          <History className="w-3 h-3" /> Entropy Implementation
                        </h5>
                        <p className="text-sm text-gray-400 italic">{output.sheAnalysis.explanation}</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Side Panels */}
              {output && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-zinc-900/40 border border-white/5 rounded-3xl p-6 lg:p-8 backdrop-blur-sm">
                    <h3 className="text-[10px] font-black text-gray-500 uppercase mb-6 flex items-center gap-2">
                      <Sparkles className="w-3 h-3 text-red-500" /> Curiosity-Gap Titles
                    </h3>
                    <div className="space-y-3">
                      {output.metadata.suggestedTitles.map((t, i) => (
                        <div key={i} className="group p-4 bg-black/40 rounded-2xl border border-white/5 hover:border-red-500/40 transition-all cursor-pointer">
                          <p className="text-sm font-bold text-gray-300 group-hover:text-white leading-snug">{t}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="bg-zinc-900/40 border border-white/5 rounded-3xl p-6 lg:p-8 backdrop-blur-sm flex flex-col">
                     <h3 className="text-[10px] font-black text-gray-500 uppercase mb-6 flex items-center gap-2">
                      <TrendingUp className="w-3 h-3 text-blue-500" /> Description & SEO
                    </h3>
                     <p className="text-xs text-gray-400 italic mb-6 leading-relaxed bg-black/20 p-4 rounded-xl border border-white/5 line-clamp-3">
                       {output.metadata.description}
                     </p>
                     <div className="flex flex-wrap gap-2 mt-auto">
                      {output.metadata.tags.map((tag, i) => (
                        <span key={i} className="px-3 py-1.5 bg-white/5 text-[10px] font-black text-gray-500 rounded-lg border border-white/5 uppercase tracking-tighter hover:text-white transition-colors cursor-default">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </main>

      <footer className="mt-auto border-t border-white/5 bg-black p-8">
        <div className="max-w-[1600px] mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-8">
             <span className="text-[10px] font-black text-zinc-700 tracking-[0.4em] uppercase">Algorithm Bypass Engine v2.6.5</span>
             <div className="hidden md:flex items-center gap-4 opacity-30 grayscale">
                <ShieldCheck className="w-4 h-4" />
                <BrainCircuit className="w-4 h-4" />
                <Settings2 className="w-4 h-4" />
             </div>
          </div>
          <div className="flex gap-4 items-center">
             <span className="text-[10px] font-black text-green-500/50 uppercase tracking-widest animate-pulse">Neural Link Optimal</span>
             <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.5)]" />
          </div>
        </div>
      </footer>
    </div>
  );
}
